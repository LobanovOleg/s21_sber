#ifndef BACKEND_S21_LOADER_H
#define BACKEND_S21_LOADER_H

#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
namespace s21 {

/** @class Loader
 *
 *  @brief The Loader class is upload objects and making parse of Verties and
 * Polygons
 */
class Loader {
 public:
  Loader() {}
  ~Loader() {}

  // getters
  std::vector<double>& GetVectorV();
  std::vector<int>& GetVectorF();
  int GetCountVertices();
  int GetCountPolygons();

  int LoadingFile(const std::string& filename);

 private:
  // FRIEND_TEST(Tester, Clearing);

  // FRIEND_TEST(Tester, IsContainValues1);
  // FRIEND_TEST(Tester, IsContainValues2);
  // FRIEND_TEST(Tester, IsContainValues3);
  // FRIEND_TEST(Tester, IsContainValues4);
  // FRIEND_TEST(Tester, IsContainValues5);
  // FRIEND_TEST(Tester, IsContainValues6);
  
  // FRIEND_TEST(Tester, SetVertices1);
  // FRIEND_TEST(Tester, SetVertices2);

  // FRIEND_TEST(Tester, SetPolygons1);
  // FRIEND_TEST(Tester, SetPolygons2);
  // FRIEND_TEST(Tester, SetPolygons3);

  // FRIEND_TEST(Tester, IsValidString1);
  // FRIEND_TEST(Tester, IsValidString2);
  // FRIEND_TEST(Tester, IsValidString3);
  // FRIEND_TEST(Tester, IsValidString4);
  // FRIEND_TEST(Tester, IsValidString5);

  // FRIEND_TEST(Tester, Parsing1);
  // FRIEND_TEST(Tester, Parsing2);
  // FRIEND_TEST(Tester, Parsing3);
  // FRIEND_TEST(Tester, Parsing4);
  // FRIEND_TEST(Tester, Parsing5);

  // FRIEND_TEST(Tester, ParseLine1);
  // FRIEND_TEST(Tester, ParseLine2);
  // FRIEND_TEST(Tester, ParseLine3);
  // FRIEND_TEST(Tester, ParseLine4);

  int Parsing(std::ifstream& file);
  // parsing and counting v-strings
  void SetVertices(const std::string& line);
  // parsing and counting polygons
  void SetPolygons(const std::string& line);

  // clearing vector_v_, vector_f_, counts of vertices and polygons. Set
  // value_max_ to -1
  void Clearing();

  // normalize to (-1..1)
  void Normalize();

  /**
   * @brief is countain valid values on input string
   * @param line input string
   * @return true/false
   */
  bool IsValidString(const std::string& line);
  std::string parseLine(const std::string& line);

  std::vector<double> vector_v_{};
  std::vector<int> vector_f_{};
  int count_vertices_ = 0;
  int count_polygons_ = 0;
  double value_max_ = -1;
};

}  // namespace s21

#endif  // BACKEND_S21_LOADER_H
