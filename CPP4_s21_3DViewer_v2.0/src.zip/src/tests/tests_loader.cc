#include "test_suite.h"

using namespace s21;

// TEST(Loader, LoadingFileErr) {
//   Loader load;

//   EXPECT_EQ(2, load.LoadingFile("obj_examples/nice_file.obj"));
// }

// TEST(Loader, LoadingFileSuccess) {
//   Loader load;

//   EXPECT_EQ(0, load.LoadingFile("obj_examples/cube.obj"));
// }

TEST_F(Tester, Clearing) {
  Loader load;

  load.LoadingFile("figure/nice_file.obj");

  load.Clearing();
  // EXPECT_EQ(0, load.GetVectorV());
  // EXPECT_EQ(0, load.GetVectorF());
  EXPECT_EQ(0, load.GetCountVertices());
  EXPECT_EQ(0, load.GetCountPolygons());
}

// TEST_F(Loader, IsContainValues1) {
//   Loader load;

//   EXPECT_FALSE(load.IsContainValues("v"));
// }

// TEST_F(Loader, IsContainValues2) {
//   Loader load;

//   EXPECT_TRUE(load.IsContainValues("v 1.0 2.0 3.0"));
// }

// TEST_F(Loader, IsContainValues3) {
//   Loader load;

//   EXPECT_FALSE(load.IsContainValues("v 1.0 abc"));
// }

// TEST_F(Loader, IsContainValues4) {
//   Loader load;

//   EXPECT_FALSE(load.IsContainValues("f"));
// }

// TEST_F(Loader, IsContainValues5) {
//   Loader load;

//   EXPECT_FALSE(load.IsContainValues("f 1.0 abc"));
// }

// TEST_F(Loader, IsContainValues6) {
//   Loader load;

//   EXPECT_TRUE(load.IsContainValues("f 1 2 3"));
// }

// TEST_F(Loader, SetVertices1) {
//   Loader load;

//   std::string line = "v 1.0 2.0 3.0";
//   load.SetVertices(line);

//   EXPECT_EQ(1, load.GetCountVertices());
//   EXPECT_EQ(1, load.GetVectorV());
// }

// TEST_F(Loader, SetVertices2) {
//   Loader load;

//   std::string line = "1.0 2.0 3.0";
//   load.SetVertices(line);

//   EXPECT_EQ(0, load.GetCountVertices());
//   EXPECT_EQ(0, load.GetVectorV());
// }

// TEST_F(Loader, SetPolygons1) {
//   Loader load;

//   std::string line = "f 1 2 3";
//   load.SetPolygons(line);

//   EXPECT_EQ(1, load.GetCountPolygons());
//   EXPECT_EQ(1, load.GetVectorF());
// }

// TEST_F(Loader, SetPolygons2) {
//   Loader load;

//   std::string line = "1 2 3";
//   load.SetPolygons(line);

//   EXPECT_EQ(0, GetCountPolygons());
//   EXPECT_EQ(0, GetVectorF());
// }

// TEST_F(Loader, SetPolygons3) {
//   Loader load;

//   std::string line = "f 1 2 3 f 4 5";
//   load.SetPolygons(line);

//   EXPECT_EQ(3, GetCountPolygons());
//   EXPECT_EQ(5, GetVectorF());
// }

// TEST_F(Loader, IsValidString1) {
//   Loader load;

//   std::string line = "v 1.0 -2.5 10.3";
//   EXPECT_TRUE(load.IsValidString(line));
// }

// TEST_F(Loader, IsValidString2) {
//   Loader load;

//   std::string line = "v 1 abc";
//   EXPECT_FALSE(load.IsValidString(line));
// }

// TEST_F(Loader, IsValidString3) {
//   Loader load;

//   std::string line = "f 1 2 3";
//   EXPECT_TRUE(load.IsValidString(line));
// }

// TEST_F(Loader, IsValidString4) {
//   Loader load;

//   std::string line = "f -1 22 acb";
//   EXPECT_FALSE(load.IsValidString(line));
// }

// TEST_F(Loader, IsValidString5) {
//   Loader load;

//   std::string line = "";
//   EXPECT_FALSE(load.IsValidString(line));
// }

// TEST_F(Loader, Parsing1) {
//   Loader load;

//   std::ifstream file("figure/empty_file.obj");
//   int result = load.Parsing(file);

//   EXPECT_EQ(1, result);
// }

// TEST_F(Loader, Parsing2) {
//   Loader load;

//   std::ifstream file("figure/valid_vertices.obj");
//   int result = load.Parsing(file);

//   EXPECT_EQ(0, result);
// }

// TEST_F(Loader, Parsing3) {
//   Loader load;

//   std::ifstream file("figure/invalid_vertices.obj");
//   int result = load.Parsing(file);

//   EXPECT_EQ(1, result);
// }

// TEST_F(Loader, Parsing4) {
//   Loader load;

//   std::ifstream file("figure/valid_polygons.obj");
//   int result = load.Parsing(file);

//   EXPECT_EQ(0, result);
// }

// TEST_F(Loader, Parsing5) {
//   Loader load;

//   std::ifstream file("figure/invalid_polygons.obj");
//   int result = load.Parsing(file);

//   EXPECT_EQ(1, result);
// }

// TEST_F(Loader, ParsLine1) {
//   Loader load;

//   std::string check = load.parseLine("Simple line");
//   EXPECT_EQ(check, "Simple line ");
// }

// TEST_F(Loader, ParsLine2) {
//   Loader load;

//   std::string check = load.parseLine("Not/Simple/Line");
//   EXPECT_EQ(check, "Not Simple ");
// }

// TEST_F(Loader, ParsLine3) {
//   Loader load;

//   std::string check = load.parseLine("Not/Simple Line/Simple/Not");
//   EXPECT_EQ(check, "Not Simple Line Simple ");
// }

// TEST_F(Loader, ParsLine4) {
//   Loader load;

//   std::string check = load.parseLine("/Line/ is /Simple/");
//   EXPECT_EQ(check, " Line  is  Simple ");
// }
