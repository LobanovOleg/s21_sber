#ifndef TEST_SUITE_H_
#define TEST_SUITE_H_

#include <gtest/gtest.h>

#include "../Model/s21_loader.h"
#include "../Model/s21_model.h"
#include "../Model/s21_transformations.h"

#endif  // TEST_SUITE_H_
