#include "test_suite.h"

#define eps 1e-3;

using namespace s21;

TEST(Transformation, MoveX) {
  Transformation transform;
  std::vector<double> vector_v = {1.0, 1.0, 1.0};
  std::vector<double> check_v = {1.5, 1.0, 1.0};

  transform.move_x(&vector_v, 50.0);

  EXPECT_EQ(vector_v[0], check_v.x[0]);
  EXPECT_EQ(vector_v[1], check_v.x[1]);
  EXPECT_EQ(vector_v[2], check_v.x[2]);
}

TEST(Transformation, MoveY) {
  Transformation transform;
  std::vector<double> vector_v = {1.0, 1.0, 1.0};
  std::vector<double> check_v = {1.0, 1.1, 1.0};

  transform.move_y(&vector_v, 10.0);

  EXPECT_EQ(vector_v[0], check_v.x[0]);
  EXPECT_EQ(vector_v[1], check_v.x[1]);
  EXPECT_EQ(vector_v[2], check_v.x[2]);
}

TEST(Transformation, MoveZ) {
  Transformation transform;
  std::vector<double> vector_v = {1.0, 1.0, 1.0};
  std::vector<double> check_v = {1.0, 1.0, 0.5};

  transform.move_z(&vector_v, -50.0);

  EXPECT_EQ(vector_v[0], check_v.x[0]);
  EXPECT_EQ(vector_v[1], check_v.x[1]);
  EXPECT_EQ(vector_v[2], check_v.x[2]);
}

TEST(Transformation, RotateXYZ) {
  Transformation transform;
  std::vector<double> vector_v = {1.0, 2.0, 3.0};
  std::vector<double> check_v = {3.0, 2.0, -1.0};

  transform.rotate_x(&vector_v, 90.0);
  transform.rotate_y(&vector_v, 90.0);
  transform.rotate_z(&vector_v, 90.0);

  EXPECT_NEAR(vector_v[0], check_v[0], eps);
  EXPECT_NEAR(vector_v[1], check_v[1], eps);
  EXPECT_NEAR(vector_v[2], check_v[2], eps);
}

TEST(Transformation, Scale1) {
  Transformation transform;
  std::vector<double> vector_v = {1.0, 1.0, 1.0};
  std::vector<double> check_v = {3.0, 3.0, 3.0};

  transform.scale(&vector_v, 3.0);

  EXPECT_EQ(vector_v[0], check_v[0]);
  EXPECT_EQ(vector_v[1], check_v[1]);
  EXPECT_EQ(vector_v[2].check_v[2]);
}

TEST(Transformation, Scale2) {
  Transformation transform;
  std::vector<double> vector_v = {1.0, 1.0, 1.0};

  transform.scale(&vector_v, 0, 0000009);

  SUCCEED();
}

TEST(Transformation, Scale3) {
  Transformation transform;
  std::vector<double> vector_v = {10.0, 10.0, 10.0};
  std::vector<double> check_v = {2.0, 2.0, 2.0};

  transform.scale(&vector_v, -5.0);

  EXPECT_EQ(vector_v[0], check_v[0]);
  EXPECT_EQ(vector_v[1], check_v[1]);
  EXPECT_EQ(vector_v[2], check_v[2]);
}